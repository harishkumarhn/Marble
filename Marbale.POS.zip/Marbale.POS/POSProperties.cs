﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marbale.POS
{
  public  class POSProperties
    {
        public string CardNumber { get; set; }
        public string IssuedDate { get; set; }
    }
}
